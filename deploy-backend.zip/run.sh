#!/bin/bash
export PORT=8080
exec npm start
